<?php
$dictionary['Contact']['fields']['no_email']['name']='no_email';
$dictionary['Contact']['fields']['no_email']['label']='LBL_NO_EMAIL';
$dictionary['Contact']['fields']['no_email']['comments']=NULL;
$dictionary['Contact']['fields']['no_email']['help']=NULL;
$dictionary['Contact']['fields']['no_email']['type']='bool';
$dictionary['Contact']['fields']['no_email']['max_size']=NULL;
$dictionary['Contact']['fields']['no_email']['require_option']='0';
$dictionary['Contact']['fields']['no_email']['default_value']='0';
$dictionary['Contact']['fields']['no_email']['audited']='0';
$dictionary['Contact']['fields']['no_email']['mass_update']='0';
$dictionary['Contact']['fields']['no_email']['duplicate_merge']='0';
$dictionary['Contact']['fields']['no_email']['reportable']='1';
$dictionary['Contact']['fields']['no_email']['importable']='true';
$dictionary['Contact']['fields']['no_email']['labelValue']='No email';
$dictionary['Contact']['fields']['no_email']['enforced']='false';
$dictionary['Contact']['fields']['no_email']['dependency']='';
$dictionary['Contact']['fields']['no_email']['readonly_formula']='';
