<?php
$mod_strings['LBL_NO_EMAIL'] = 'No email';
